<?php
require_once 'core/init.php';
require 'PHPMailer_5.2.1/class.phpmailer.php';
//include 'automate.php';

$auto = new Automate();
$auto->Automate();



$user = new User();
if( !$user->isLoggedIn() ){
 	//Redirect::to('index.php');
 	Redirect::to('login.php');
}


?>

<!DOCTYPE html>
<html>
<head>
	<title>A.I.S</title>
	<meta name="viewport" content="width=device-width, initial-sacle=1">
	<script type="text/javascript" src="js/jquery.js"></script>
	
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="css/custom.css">
	<script type="text/javascript" src="js/bootstrap.min.js"></script>

	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

	<style type="text/css">
			.border-color{
				border:2px solid #69C3DE !important;
			}

			.iconic-color{
				color: #E82F3E;
				font-size:18px;
			}

			.icon-red{
				color: red;
				font-size:18px;
			}

			.icon-yellow{
				color: #FAB43F;
				font-size:18px;

			}

			.icon-cream{
				color: #7CFC00;
				font-size:18px;

			}

			.icon-darkorange{
				color: #FF7500;
				font-size:18px;
			}

			.icon-intensered{
				color: #CC2900;
				font-size:18px;
			}

			.icon-ligthgreen{
				color: #F67656;
				font-size:18px;
			}


	</style>



</head>
<body style="background-color: #F0EBDF !important;">

	<!-- # NAV -->
	<?php include 'includes/layout/nav.php'; ?>


	<!-- # CONTAINER -->
     <div style="padding-right: 40px !important; padding-left: 40px !important;">
			    <p>
					<div class="well border-color">
					<!-- # WELL <div class="well"> -->
						  
					    <table class="table">
						 		<thead class="thead-dark">
						 			<tr>
						 				<th colspan="2" ><h3>Clients:  <img src="images/icon2.png" class="img-fluid" alt="" width="65" height="65"> </h3></th>
						 				
						 			</tr>
						 		</thead>

						 		
						 </table>


						 <ul class="list-group">
					   	 <li class="list-group-item">

					   	 <img class="img-fluid img-rounded" src="images/bi2.png" style="width: 100%;height: 95px;">


					   	  <hr/>

					   	 <!-- #NAVIGATION BUTTON -->


					   	 <div id="success_msg" class="text-center">
					 
					   	 </div>

					   	 <div id="results" class="text-center">
					 
					   	 </div>
					   	
					   
						 <form action="" method="post" id="search_form">

						 	<div class="table-responsive">

						 	<table class="table">
							  <thead class="thead-dark">
							    <tr>
							      <th class="success" scope="col">#</th>
							      <th class="success" scope="col">Client Name</th>
							      <th class="success" scope="col">Client Code</th>
							      <th class="success" scope="col">Available Credits</th>
							      <th class="success" scope="col">Email</th>
							      <th class="success" scope="col">Phone Number</th>
							      <th class="success" scope="col">Created At</th>
							      <th class="success" scope="col">Suspend</th>
							      <th class="success" scope="col">Update</th>
							    </tr>
							  </thead>

							  <tbody id="clients_output"></tbody>

							</table>

						</div>

						
					   	  	
					   	  </form>

					   	 </li>
					   	 </ul>

					</div>
				</p>

	 </div>
			



	<!-- # FOOTER -->
	<footer class="footer navbar-fixed-bottom text-center">
		<p>Copyright <?php echo date('Y'); ?> &copy; A.I.S </p>
	</footer>

</body>
</html>

<script type="text/javascript">
$(document).ready( function(){

	//NOTE THESE ARE CLIENTS
	fetch_data();

	function fetch_data(){

		$.ajax({
			url:"fetch_clients.php",
			success:function(data){

				$('#clients_output').html(data);
			}
		})
	}


	//SUSPEND USER: SET 1 True, 0 = False (Not Suspened)
	$(document).on('click', '.suspend', function(){


        	var suspend_id = $(this).attr('id');
        	var action = "suspend"; 

			$.ajax({
				url:"action.php",
				method:"POST",
				data:{suspend_id:suspend_id, action:action},
				success:function(data){

					alert(data);
					location.reload(); 
					
				}

			});

			

	});


	/* EDIT THE CLIENT */
	//EDIT THE CLIENT
	$(document).on('click', '.edit', function(){

		    var edit_id = $(this).attr('id');
		    window.location.href = "edit.php?id=" + edit_id;

	});


}); 

</script>