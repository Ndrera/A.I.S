<?php
require_once 'core/init.php';
require('fpdf182/fpdf.php');


$id 		  	= Input::get('id');
$date_from    	= Input::get('from');
$date_to 	  	= Input::get('to');
$company_name 	= 'Motor Accident Group';
$subtotal 	  	= 0;
$vat_total 	  	= 0;
$total_amount 	= 0;
$branch_init  	= '';
$address_line1  = '';
$address_line2  = '';
$address_line3  = '';
$address_line4  = '';


$custom 	= new CustomsBranch();
if( $custom->find($id ) ){

	$data_name = CustomsDB::getInstance()->query("SELECT branch_code FROM branch WHERE id = $id");
	foreach( $data_name->results() as $name ){
		//$name->registered_name;
		$name->branch_code;
	}


	$data = CustomsDB::getInstance()->query("SELECT * FROM branch_invoice bi 
			WHERE (bi.date_invoiced BETWEEN '$date_from' AND '$date_to') AND bi.branch_id = $id");


}else{

	$data_name = DB::getInstance()->query("SELECT branch_code FROM branch WHERE id = $id");
	foreach( $data_name->results() as $name ){
		//$name->registered_name;
		$name->branch_code;
	}

	$data = DB::getInstance()->query("SELECT * FROM branch_invoice bi 
			WHERE (bi.date_invoiced BETWEEN '$date_from' AND '$date_to') AND bi.branch_id = $id");

}


#STATIC DATA
switch ($name->branch_code) {
  case "MAG1001":
      $branch_init = "MS";

      $address_line1  = '80 Booysens Road';
	  $address_line2  = 'Selby';
	  $address_line3  = '2001';
	  $address_line4  = '';

    break;

  case "MAG1002":
  	  $branch_init = "ML";

  	  $address_line1  = '42 Longmeadow';
	  $address_line2  = 'Edenvale';
	  $address_line3  = '1609';
	  $address_line4  = '';

    break;

  case "MAG1003":
      $branch_init = "MGC";

      $address_line1  = 'Lois Avenue';
	  $address_line2  = 'Glen Eagles, Glenanda';
	  $address_line3  = '7945';
	  $address_line4  = '';

    break;

  case "MAG1004":
       $branch_init = "ME";

      $address_line1  = '80 Booysens Road';
	  $address_line2  = 'Selby';
	  $address_line3  = '2001';
	  $address_line4  = '';



    break;

  default:
    $branch_init = "";

}


#INVOICE DATA
if( !$data->count() ){
    #NO DATA FOUND IN THE DATABASE
	echo "No invoice data found";
	
}else{

 
	foreach( $data->results() as $result ){  

		#INVOICE
		/*A4 width : 219mm*/
		$pdf = new FPDF('P','mm','A4');

		$pdf->AddPage();
		/*output the result*/

		/*set font to arial, bold, 14pt*/
		$pdf->SetFont('Arial','B',20);

		/*Cell(width , height , text , border , end line , [align] )*/

		#BLOCK 1
		$pdf->Cell(71 ,10, $pdf->Image('images/ict_logo.png',6,6,49),0,0);
		$pdf->Cell(59 ,5,'',0,0);
		$pdf->Cell(59 ,10,'TAX INVOICE',0,1);
		$pdf->Ln(24);

		#BLOCK 2
		$pdf->SetFont('Arial','B',10);

		$pdf->Cell(130 ,5,'',0,0);    //ADDIND SPACE
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		
		$pdf->Cell(130 ,5,'Platinum ICT (Pty) LTD',0,0);  
		$pdf->Cell(25 ,5,'Invoice No:',0,0);
		$pdf->Cell(34 ,5, $branch_init.$result->invoice_no,0,1);


		$pdf->Cell(130 ,5,'VAT No: 4380274177',0,0);
		$pdf->Cell(25 ,5,'Invoice Date:',0,0);
		$pdf->Cell(34 ,5, $result->date_invoiced,0,1);
		 
		$time = strtotime( $result->date_invoiced );
		$final = date("Y-m-d", strtotime("+1 week", $time));

		$pdf->Cell(130 ,5,'Reg: 2014/281031/07',0,0);
		$pdf->Cell(25 ,5,'Due Date:',0,0);
		$pdf->Cell(34 ,5,$final,0,1);

		$pdf->Cell(130 ,5,'Unit 6b Monpark Center',0,0);
		$pdf->Cell(25 ,5,'Sales Rep:',0,0);
		$pdf->Cell(34 ,5,'A.I.S',0,1);

		$pdf->Cell(130 ,5,'76 Skilpad Street',0,0);
		$pdf->Cell(25 ,5,'Print Date:',0,0);
		$pdf->Cell(34 ,5,date("Y-m-d"),0,1);

		$pdf->Cell(130 ,5,'Monument Park, Pretoria',0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,'0181',0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,'',0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);


		#BLOCK 3
		$pdf->SetFont('Arial','B',15);
		$pdf->Cell(130 ,5,'Invoice To:',0,0);
		$pdf->Cell(59 ,5,'',0,0);
		$pdf->SetFont('Arial','B',10);
		$pdf->Cell(189 ,10,'',0,1);


		$pdf->Cell(130 ,5,$company_name,0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,$address_line1,0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,$address_line2,0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,$address_line3,0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		$pdf->Cell(130 ,5,$address_line4,0,0);
		$pdf->Cell(25 ,5,'',0,0);
		$pdf->Cell(34 ,5,'',0,1);

		#BLOCK 4

		$pdf->SetFont('Arial','B',10);
		/*Heading Of the table*/

		$pdf->SetDrawColor(194, 193, 190);
		$pdf->SetFillColor(194, 193, 190);
	    
		$pdf->Cell(108 ,6,'Description',0,0,'L', true);
		$pdf->Cell(20 ,6,'Quantity',0,0,'L', true);
		$pdf->Cell(25 ,6,'Unit Price',0,0,'L', true);
		
		$pdf->Cell(35 ,6,'Total Price',0,1,'L', true);/*end of line*/
		/*Heading Of the table end*/
		$pdf->SetFont('Arial','',10);
			foreach( $data->results() as $res ){
				
				#[ C = Center ] [ R = Right ] [ L = Left ]
				$pdf->Cell(108 ,6, 'Advanced Intelligence System',0,0,'L');
				$pdf->Cell(20 ,6,$res->quantity,0,0,'L');
				$pdf->Cell(25 ,6, 'R'. $res->unit_price,0,0,'L');
				$pdf->Cell(35 ,6, 'R'. $res->total_price,0,1,'l');

				$subtotal 	 += $res->total_price;
				$vat_total 	  = ( $subtotal * 0.15 );
				$total_amount = $subtotal + $vat_total;

			}
			
		#BLOCK 5    [ FOR TOTAL ]
	    $pdf->SetY(-60);

		$pdf->SetFont('Arial','',10);
		/*Heading Of the table*/
		$pdf->Cell(128 ,6,'Platinum Internet Communication and Telecommunications',1,0,'L', true);
		$pdf->Cell(25 ,6,'SUBTOTAL',0,0,'L', true);
		$pdf->Cell(35 ,6, "R " . number_format($subtotal, 2) ,0,1,'L', true);/*end of line*/


		$pdf->Cell(128 ,6,'FNB Business Cheque Account',1,0,'L' , true);
		$pdf->Cell(25 ,6,'VAT@15%',0,0,'L');
		$pdf->Cell(35 ,6,"R " . number_format($vat_total, 2),0,1,'L');/*end of line*/

		$pdf->Cell(128 ,6,'Branch Code 250655',1,0,'L', true);
		$pdf->Cell(25 ,6,'TOTAL',0,0,'L', true);
		$pdf->Cell(35 ,6,"R " .  number_format($total_amount,2) ,0,1,'L', true);/*end of line*/

		$pdf->Cell(128 ,6,'Account No. 62517320727',1,0,'L', true);
		$pdf->Cell(25 ,6,'',0,0,'L');
		$pdf->Cell(35 ,6,'',0,1,'L');/*end of line*/

		$pdf->Cell(128 ,6,'',1,0,'L', true);
		$pdf->Cell(25 ,6,'',0,0,'L');
		$pdf->Cell(35 ,6,'',0,1,'L');/*end of line*/

		$pdf->Cell(128 ,6,'Please reference your invoice number when processing payment',1,0,'L', true);
		$pdf->Cell(25 ,6,'',0,0,'L');
		$pdf->Cell(35 ,6,'',0,1,'L');/*end of line*/


		$pdf->Output("I", $branch_init.$result->invoice_no . ".pdf"); 


	}


} 

?>