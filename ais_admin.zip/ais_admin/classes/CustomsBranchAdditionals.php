<?php
class CustomsBranchAdditionals{

	/**
	* Properties
	**/
	private $_db,
			$_data,
			$_sessionName,
			$_isLoggedIn,
			$_cookieName;


	
	public function __construct( $user = null ){
		#Set the db property to db instance
		$this->_db = CustomsDB::getInstance();

		#Declare cookies and sessions
		$this->_sessionName = Config::get('session/session_name');
		$this->_cookieName = Config::get('remember/cookie_name');	
		
		if( !$user ){
			if( Session::exists($this->_sessionName) ){

				$user = Session::get( $this->_sessionName ); 

				#Check if user exists. 
				#We do this becase we dont wanna keep calling find in each and every page when we want to do this. [ $user->data()->id ]
				if( $this->find($user) ){  #e.g id = 4
					$this->_isLoggedIn = true;
				}else{
				}
			}

		}else{

			#If user has been defined in the parameters
			#eg. [ $user = new User(6) | User('BossLady')]
			$this->find( $user );
		}


	}


	/**
	* Create a create() method
	* This method create a user, if it fails throws an exception
	**/
	public function create( $fields = array() ){
		if( !$this->_db->insert('branch_additionals', $fields) ){

			throw new Exception('There was a problem creating an account.');

		}
	}


	/**
	* Create the find() method.
	* To find the first() results set of user data.
	* Retrive/get data either by "id" or "username"
	* We awant the first() data set
	* Then store the data in the _data property, then return true
	* pass a "user = null", that will determine if its "id" or 
	* "username"
	**/
	public function find( $user = null ){
		if( $user ){
			#Note:: are we allowing numeric username. Make username alphanumeric
			$field = ( is_numeric($user) ) ? 'id' : 'username';
			$data  = $this->_db->get( 'branch_additionals', array($field, '=', $user) );

			if( $data->count() ){
				$this->_data = $data->first();  //Get first
				return true;
			}


		}
		return false;


	}


	/**
	* Create the login() method, to process the user login in
	* Pass "username" and "password", later "remember"
	* Cater for null parateters e.g $this->login()
	**/
	//public function login( $username = null, $password = null ){
	public function login( $username = null, $password = null, $remember = false ){

		if( !$username && !$password && $this->exists() ){
			Session::put( $this->_sessionName, $this->data()->id );

		}else{
			
			$user = $this->find( $username );

			# $user = true/1
			if( $user ){

				#Do hashed passwords match 
				#[if DB password = Form Inputed password]
				if( $this->data()->password === Hash::make( $password, $this->data()->salt)){

					#PROBLEM IS HERE: PASSWORD NOT MATCHING

					//echo "OK";
					#PUT user_id in the session for the user class
					# $_SESSION[user] = 5
					Session::put( $this->_sessionName, $this->data()->id );
					//return true;

					#LATER ADD REMEMBER ME
					#Chek if remember me is true or false
					if( $remember ){  //True

						#BUILD A FIRST COOKIE [ Cookie.php class ]
						#unique hash. Get logged in user from "users_session". Check if its found, if not insert, else Pass DB hash the first one.
						#Save the Cookie
						$hash = Hash::unique();

						$haskCheck = $this->_db->get( 'users_session', array( 'user_id', '=', $this->data()->id ) );

						if( !$haskCheck->count() ){
							#No has is in the DB with this logged in user id. INSERT
							$this->_db->insert( 'users_session', array(
								'user_id' => $this->data()->id,
								'hash'	  => $hash
							) );

						}else{
							#Hash is found in the DB. Get the first()
							#No duplication in the DB
							$hash = $haskCheck->first();
						}

						#Save the cookie
						Cookie::put( $this->_cookieName, $hash, Config::get('remember/cookie_expiry') );
						
					}
					return true;


				}

			}

		}

		return false;


	}



	/**
	* Create a data() method.
	* This returns the _data set from the find() method
	* Note: it returns all the DB fields [id, username,password,
	* salt, etc ]
	* Note: $this->_data was assigned in the find() method
	**/
	public function data(){
		return $this->_data;
	}


	/**
	* Create the isLoggedIn() method
	* To check if a user is logged in or not using true or false
	* Note: i will put what in the constructor here
	**/
	public function isLoggedIn(){
		return $this->_isLoggedIn;
	}


    /**
    * Create the logout() method, to allow a user to logout
    * We gonna jst delete the session name, that we declared lapha
    * phezulu
    * Also delete the cookie
    * Also remove the cookie from DB
    **/
    public function logout(){
    	$this->_db->delete( 'users_session', array(
    			'user_id', '=', $this->data()->id
    	) );
    	
    	Session::delete( $this->_sessionName );
    	Cookie::delete( $this->_cookieName );

    }


    /**
    * Check if the user exists()
    * To determine f user exists or not, Is if  we have retrieved 
    * data from them a user at some point>
    **/
    public function exists(){
    	return ( !empty($this->_data) ) ? true : false;
    }


    /**
    * Creat an update() method, that passes an array.
    * Give the user the ability to change their profile details
    * Note: we already have the update method in the DB.php class
    * So this wont do too much, because we already have update in 
    * DB.php class
    * It passes an array with elements and values
    * Note: we need to call the update() method on a DB object
	*
    * Pass an id as null in parameters to avoid functionality 
    * breaking
    **/
    //public function update( $fields = array(), $id = null ){
    public function update(  $fields = array(), $id = null ){
    	#We need to get this id, from somewhere. We want to make sure that this functionality doesnt break, if the is no id available for some reason.
    	#Note: if the is nor id defined in parameters then get the current logged in user [ $id = $this->data()->id ]. Otherwise use the one passed in the parameters.

    	if( !$id && $this->isLoggedIn() ){
    		$id = $this->data()->id;
    	}

    	#If not update, throw an exception
    	if( !$this->_db->update( 'branch_additionals', $id, $fields ) ){
    	//if( !$this->_db->update( 'users_ooplr', $id, $fields ) ){
    		throw new Exception("There was a problem updating.");
    		
    	}


    }


    /**
	* Create has Permission() method, to get users permission
	* The method will extract user permission from DB
	* We need the ability to define what kund of key we are looking 
	* for.
	* by passing it as parameters: e.g hasPermission('admin') | 
	* ('moderator')
	* We also have key value pair as we have seen in the DB 
	* {'admin':1}
	* But we want to determine what group they are actually in first
	* of all.
	* id = $this->data()->group | [ 1 = 1 ]
	* Note: the are many users with group 1, but i want the first()
	**/
	public function hasPermission( $key ){
		$group = $this->_db->get( 'groups', array( 
				'id', '=', $this->data()->group
		) );

		//print_r( $group->first() );

		#First check if the user group is in the groups TB or not
		#Then extract the permissions
		#Then decode json to array
		//print_r( $group->count() );
		if( $group->count() ){
			//echo "Group found";
			//echo $permissions = $group->first()->permissions;

			$permissions = json_decode( $group->first()->permissions, true );
			//print_r( $permissions );

			#$permission['admin']
			//var_dump( $permissions['admin'] == true); //true
			if( $permissions[$key] == true ){
				//echo 'ok';
				return true;
			}


		}
		return false;
		
	}





}