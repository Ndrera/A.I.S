<?php
class Automate{

	/*
	 SMS AND EMAIL  
	*/
	public function Automate(){

		$output = '';
		$ais_notification_id = '';

		$db = DB::getInstance();
		if($db){

			$data =  $db->query("SELECT b.id, b.branch_name, b.branch_credits, ba.emp_email, ba.emp_contact_number, ba.sent_status, ba.sent_date, ba.sent_count 
				FROM  branch b 
				INNER JOIN branch_additionals ba ON b.id = ba.branch_id 
				WHERE b.branch_credits <= 30");

			if( !$data->count() ){
			    #NO DATA FOUND IN THE DATABASE
				$output .= "No table records are found on this table.";

			}else{

				foreach( $data->results() as $result ){

					#CHECK IF AN SMS AND EMAIL HAS ALREADY BEEN SENT OUT TODAY
					if( $result->sent_status != 1 && $result->sent_date != date("Y-m-d") ){
							
							#SEND SMS
							// Instantiate Class
							$mail = new PHPMailer();
							 
							// Set up SMTP
							$mail->IsSMTP();                // Sets up a SMTP connection
							//$mail->SMTPDebug  = 2;          // This will print debugging info
							$mail->SMTPAuth   = true;         // Connection with the SMTP does require authorization
							$mail->SMTPSecure = "TLS";      // Connect using a TLS connection
							$mail->Host       = "mail.2way.co.za";
							$mail->Port       = 587;
							$mail->Encoding   = '7bit';       // SMS uses 7-bit encoding
							 
							// Authentication
							$mail->Username   = "22041"; // Login
							$mail->Password   = "track2"; // Password
							$mail->Mailer     = "smtp";
						
							#SMS Data
							$toNum = substr( $result->emp_contact_number, 1 );
							$branch_name = $result->branch_name;
							$branch_credits = $result->branch_credits;
							$message = "Good day ".$branch_name.", You are running low on credits. You have ".$branch_credits." credits remaining.";

							// Compose
							$mail->From = "track2@2way.co.za";
							
							// Send To
							$mail->Subject = "AIS"; 
							$mail->Body = "$message";
							$to = "+27" . $toNum ."@2way.co.za";//Customer

						  	$mail->addAddress($to);

							if(!$mail->send()) {
								echo "Mailer Error: " . $mail->ErrorInfo;
								//$rslt = 0;
							}
							$clear = $mail->clearAddresses();
							//echo("Encryption Code:#fe52a2820f2224ef6f6d09652c2bc5a2");

							

							$branch_name = $result->branch_name;
							$branch_credits = $result->branch_credits;
							$message = "Good day ".$branch_name.", You are running low on credits. You have ".$branch_credits." credits remaining.";


							#SEND EMAIL
							$mail = new PHPMailer();
						    $mail->isSMTP();
						    $mail->Host = 'smtp.gmail.com';
						    $mail->Port = 587;
						    $mail->SMTPSecure = 'tls';
						    $mail->SMTPAuth = true;
						    $mail->Username = "mag.accounzi2018@gmail.com";
						    $mail->Password = "123coded";
						    $mail->setFrom("mag.accounzi2018@gmail.com", 'Advanced Intelligence System');
						    $mail->addReplyTo('info@motoraccidentgroup.co.za', 'Advanced Intelligence System');

						    $mail->addAddress($result->emp_email, '');
						    $mail->Subject = 'Advanced Intelligence System Notification';
						    $mail->AltBody    = "";
						    $mail->Body = $message;

						    if (!$mail->send()) {
						        //echo 0;
						        echo "Mailer Error: " . $mail->ErrorInfo;
						    }

						    $mail->clearAddresses();
						    
						    #SMS AND EMAIL SENT
						    $update = $db->update( 'branch_additionals', $result->id, array(
									'sent_status'  			=> 1,	
									'sent_date'				=> date("Y-m-d"),
									'sent_count'			=> ++$result->sent_count

							) );

							/*
	
							$update = $db->update( 'branch_additionals', $result->id, array(
									'sent_status'  			=> 1,	
									'sent_date'				=> date("Y-m-d")

							) );
							*/

							
							#EMAIL AND SMS SENT
							
					}
					

				}
			}


		}




		#CUSTOMS DATA
		#CUSTOMS DATA
		$cust_db = CustomsDB::getInstance();
		if( $cust_db ){

			$customs_data =  $cust_db->query("SELECT b.id, b.branch_name, b.branch_credits, ba.emp_email, ba.emp_contact_number, ba.sent_status, ba.sent_date, ba.sent_count 
				FROM  branch b 
				INNER JOIN branch_additionals ba ON b.id = ba.branch_id 
				WHERE b.branch_credits <= 30");

			if( !$customs_data->count() ){
			    #NO DATA FOUND IN THE DATABASE
				$output .= "No table records are found on this table.";

			}else{

				foreach( $customs_data->results() as $custom_result ){

					$date = date("Y-m-d");
				    if( $custom_result->sent_status != 1 && $custom_result->sent_date != $date ){
					
							#SEND SMS
							// Instantiate Class
							$mail = new PHPMailer();
							 
							// Set up SMTP
							$mail->IsSMTP();                // Sets up a SMTP connection
							//$mail->SMTPDebug  = 2;          // This will print debugging info
							$mail->SMTPAuth   = true;         // Connection with the SMTP does require authorization
							$mail->SMTPSecure = "TLS";      // Connect using a TLS connection
							$mail->Host       = "mail.2way.co.za";
							$mail->Port       = 587;
							$mail->Encoding   = '7bit';       // SMS uses 7-bit encoding
							 
							// Authentication
							$mail->Username   = "22041"; // Login
							$mail->Password   = "track2"; // Password
							$mail->Mailer     = "smtp";
						
							#SMS Data
							$toNum = substr( $custom_result->emp_contact_number, 1 );
							$branch_name = $custom_result->branch_name;
							$branch_credits = $custom_result->branch_credits;
							$message = "Good day ".$branch_name.", You are running low on credits. You have ".$branch_credits." credits remaining.";

							// Compose
							$mail->From = "track2@2way.co.za";
							
							// Send To
							$mail->Subject = "AIS"; 
							$mail->Body = "$message";
							$to = "+27" . $toNum ."@2way.co.za";//Customer

						  	$mail->addAddress($to);

							if(!$mail->send()) {
								echo "Mailer Error: " . $mail->ErrorInfo;
							}
							$clear = $mail->clearAddresses();
							
							

							#SEND EMAIL
							$branch_name = $custom_result->branch_name;
							$branch_credits = $custom_result->branch_credits;
							$message = "Good day ".$branch_name.", You are running low on credits. You have ".$branch_credits." credits remaining.";

							#SEND EMAIL
							$mail = new PHPMailer();
						    $mail->isSMTP();
						    $mail->Host = 'smtp.gmail.com';
						    $mail->Port = 587;
						    $mail->SMTPSecure = 'tls';
						    $mail->SMTPAuth = true;
						    $mail->Username = "mag.accounzi2018@gmail.com";
						    $mail->Password = "123coded";
						    $mail->setFrom("mag.accounzi2018@gmail.com", 'Advanced Intelligence System');
						    $mail->addReplyTo('info@motoraccidentgroup.co.za', 'Advanced Intelligence System');

						    $mail->addAddress($custom_result->emp_email, '');
						    $mail->Subject = 'Advanced Intelligence System Notification';
						    $mail->AltBody    = "";
						    $mail->Body = $message;

						    if (!$mail->send()) {
						       // echo 0;
						        echo "Mailer Error: " . $mail->ErrorInfo;
						    }
						    $mail->clearAddresses();

						 

						    #UPDATE SMS
						    //$date = date("Y-m-d");
							$id   = $custom_result->id;
							$sent_count = ++$custom_result->sent_count;
							$update = $cust_db->query("UPDATE branch_additionals SET sent_status=1,sent_date='$date',sent_count=$sent_count WHERE branch_id=$id");

							/*
							$id   = $custom_result->id;
							$update = $cust_db->query("UPDATE branch_additionals SET sent_status=1,sent_date='$date' WHERE branch_id=$id");
							*/
							
							#EMAIL AND SMS SENT
					
					}

				}
			}

		}



	}
}

?>