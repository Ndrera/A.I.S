<?php
class Hash{

	const _SALT = "$(*&%$@e03e5bd3a1d64fa2d7aafd866";
	


	/*
    * Hashing a string
    *
    **/
    public static function make( $string, $salt = '' ){
    	#return using a hash function and concatinate a salt that we provide
    	#The salt will be empty if we dont provide it

    	return hash( 'sha256', $string . $salt );
    }


    /**
    * Generate a salt with a particular length
    **/
    /*
    public static function salt( $length ){
    	//return mcrypt_create_iv( $length );
        //openssl_random_pseudo_bytes($length)
        return random_bytes( $length );

    }
    */
    public static function salt( ){
        //return $length = "$(*&%$@e03e5bd3a1d64fa2d7aafd866";
        return self::_SALT;

    }


    /**
    * Unique hash value
    **/
    public static function unique(){
    	return self::make( uniqid() );
    }


}