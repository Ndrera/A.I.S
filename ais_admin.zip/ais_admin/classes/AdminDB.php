<?php
class AdminDB{

	private static $_instance = null;
	private $_pdo,
	        $_query,
	        $_error = false,
	        $_results,
	        $_count = 0;


	
	private function __construct(){
		try{
			$this->_pdo = new PDO('mysql:host=' . Config::get('local/host') . ';dbname=' . Config::get('local/db'), Config::get('local/username'), Config::get('local/password'));

		} catch( PDOException $e ){
			die( $e->getMessage() );
		}

	}


	public static function getInstance(){
		if( !isset(self::$_instance) ){ 

			self::$_instance =new AdminDB(); 
		}
		return self::$_instance;  
	}


	/**
	* Generic query method
	**/
	public function query( $sql, $params = array() ){
		$this->_error = false; 

		if( $this->_query = $this->_pdo->prepare( $sql ) ){

			$x = 1;  
			if( count($params) ){
				foreach( $params as $param ){

					$this->_query->bindValue($x, $param);
					$x++;

				}
			}

			
			if( $this->_query->execute() ){

				#Store the results set. fetch all and count
				$this->_results = $this->_query->fetchAll(PDO::FETCH_OBJ);
				$this->_count   = $this->_query->rowCount();

			}else{
				$this->_error = true;
			}

		}

		return $this;  

	}


	/**
	* Results set
	**/
	public function results(){
		return $this->_results;
	}



	/**
	* Error
	**/
	public function error(){
		return $this->_error;
	}


	/**
	* Generic action method
	**/
	public function action( $action, $table, $where = array() ){

		#Check if where array has 3 elements
		if( count($where) === 3 ){
			$operators = array('=', '>', '<', '>=', '<=');

			$field    = $where[0];
			$operator = $where[1];
			$value 	  = $where[2];

			#Check if the operator is in the defined list
			if( in_array($operator, $operators) ){

				$sql = "{$action} FROM {$table} WHERE {$field} {$operator} ?";
				
				if( !$this->query($sql, array($value))->error() ){
					return $this;
				}

			}
		}

		return false;

	}
     
	/**
	* Fetch all data from DB table
	**/
	public function get( $table, $where ){

		return $this->action('SELECT *', $table, $where);
	}


	/**
	* Delete table data
	**/
	public function delete( $table, $where ){
		return $this->action('DELETE', $table, $where);
	}



	/**
	* Count method to see if the are any records found
	* with that query executed
	**/
	public function count(){
		return $this->_count;
	}



	/**
	* Returns the first result set
	* from the TB data
	**/
	public function first(){
		//return $this->_results[0];

		#Even better we can return it like this, by using the results method
		return $this->results()[0];
	}


	/**
	* Save data
	**/
	public function insert( $table, $fields = array() ){
		
			$keys = array_keys( $fields ); //Get the array field
			
			$values = '';
			$x = 1;

			foreach( $fields as $field ){
				$values .= '?';

				$values .= $x < count( $fields ) ? ', ' : '';
				$x++;

			}


			$sql = "INSERT INTO {$table} (`" . implode('`, `', $keys) . "`) VALUES ({$values})";
			
			#Run the query
			if( !$this->query($sql, $fields)->error() ){
				return true;
		    }
		return false;
	}



	/**
	* Update the data in the database
	**/
	public function update( $table, $id, $fields ){
		$set = '';
		$x = 1;

		foreach( $fields as $name => $value ){
			#NOTE: we always want to bind the data, to prevent sql injection
			$set .= "{$name} = ?";

			if( $x < count($fields) ){
				$set .= ', ';
			}
			$x++;

		}

		$sql = "UPDATE {$table} SET {$set} WHERE id = {$id}";
		//echo $sql;
		if( !$this->query($sql, $fields)->error() ){
			return true;
		}
		return false;
	}


}