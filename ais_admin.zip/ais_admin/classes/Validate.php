<?php
class Validate{

	/**
	* Properties
	**/
	private $_passed = false,
		 	$_errors = array(),
		 	$_db	 = null;

    
    /**
    * Constructor establishes the DB connection using the DB instance.
    * By setting the instance to the _db variable.
    **/
    public function __construct(){
    	$this->_db = DB::getInstance();
    }


    /**
    * Validates the data against predefined conditions [e.g min, max, required, etc]
	**/
	public function check( $source, $items = array() ){

		#The main idea here is to list through all the items, we have defined, and foreach of them we
		#want to list through the rules inside of them and check them against the source we provided.
		foreach( $items as $item => $rules ){

			#Loop through them set of rules
			foreach( $rules as $rule => $rule_value ){
				$value = trim( $source[$item] );

				$item = escape( $item );
				
				if( $rule === 'required' && empty($value) ){
					$this->addError("{$item} is required");

				}elseif( !empty($value) ) {

					#Test for other rules min, max, etc using a switch
					switch( $rule ){
						case 'min':

							 if ( strlen($value) < $rule_value ) {
							 	 $this->addError("{$item} must be a minimum of {$rule_value} characters.");
							 }
						break;

						case 'max':

							if( strlen($value) > $rule_value ){
								#NOTE: addError process errors as array
								$this->addError("{$item} must be a maximum of {$rule_value} characters.");
							}
						break;

						case 'matches':

							if( $value != $source[$rule_value] ){
								$this->addError("{$rule_value} must match {$item}");
							}
						break;

						case 'unique':

							#Use database wrapper to check for unique
							$check = $this->_db->get($rule_value, array($item, '=', $value));
				
							#Results returned
							if( $check->count() ){
								$this->addError("{$item} already exists");
							}
							
						break;

						#VALIDATE PHONE NUMBER
						case 'valid':
								 
							 	  if( !preg_match("/^\+?\d{0,3}[0-9]{2}[0-9]{3}[0-9]{4}$/", $value) ){
								 	  $this->addError("You entered an incorrect {$item}.");
								  }

						break;


						#VALIDATE AN EMAIL
						case 'valid_email':
								if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
									 $this->addError("You {$item} is incorrect.");
								}

						break;

					}
				}

			}
		}

		# Have a quick check after looping. Check if our errors array is empty or not
		if( empty($this->_errors) ){
			$this->_passed = true;
		}
		

		return $this;  #To chain methods eg. [ check()->errors()]
	}



	/**
	* Adds an error in the errors[] array
	**/
	private function addError( $error ){
		$this->_errors[] = $error;
	}



    /**
    * Returns an error, added to the AddError method
    **/
    public function errors(){
		return $this->_errors;
    }


    /**
    * Boolean method that checks if validation is passed and then returns true or false
    **/
    public function passed(){
    	return $this->_passed;
    }


}