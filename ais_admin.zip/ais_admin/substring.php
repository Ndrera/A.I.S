<?php
require_once 'core/init.php';


/*
$string = "0|IN_PROGRESS|1109181415";
echo substr($string,0,1)."<br>";
echo */

//Array ( [0] => 0 [1] => IN_PROGRESS [2] => 1109181415 ) 
$string  = "0|IN_PROGRESS|1109181415";
$explode = explode("|", $string); 

//echo $explode;
//print_r( $explode[0] );
print_r( $explode[0] );

//Redirect::to(404);
//Redirect::to('best.php');


?>