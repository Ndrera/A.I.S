<?php
require_once 'core/init.php';
require 'PHPMailer_5.2.1/class.phpmailer.php';


const _SENT_SMSES   = 'sent_smses';
const _SEND_SMS     = 'send_sms';
const _SEND_EMAIL   = 'send_email';

#SENT SMS
if( Input::get('action') == _SENT_SMSES ){

    $output     = '';

    #ALL BRANCHES
    $data = DB::getInstance()->query("SELECT b.id, b.branch_name, b.branch_code, b.branch_credits, b.branch_contact, b.branch_email, b.date_modified, ba.suspend_status, ba.sent_count 
      FROM branch b 
      INNER JOIN branch_additionals ba ON b.id = ba.branch_id");


    if( !$data->count() ){
        #NO DATA FOUND IN THE DATABASE
      $output .= "
      <tr>
          <td>No table records are found on this table.</td>
      </tr>
      ";

    }else{

      $x = 1;
      foreach( $data->results() as $result ){
          
         $output .= '
            <tr>
              <th>'. $x .'</th>
              <th>' . $result->branch_name . '</th>
              <th><p style="color:#C9302C">' . $result->sent_count . '</p></th>
              <th><p style="color:green">' . $result->sent_count . '</p></th>
              
            </tr>
            ';      

        $x++;

      }


    }




    #CUSTOMS
    $custom_data = CustomsDB::getInstance()->query("SELECT b.id, b.branch_name, b.branch_code, b.branch_credits, b.branch_contact, b.branch_email, b.date_modified, ba.suspend_status, ba.sent_count 
      FROM branch b 
      INNER JOIN branch_additionals ba ON b.id = ba.branch_id");


    if( !$custom_data->count() ){
        #NO DATA FOUND IN THE DATABASE
      $output .= "
      <tr>
          <td>No table records are found on this table.</td>
      </tr>
      ";

    }else{

     // $x = 1;
      foreach( $custom_data->results() as $custom_result ){
          
         $output .= '
            <tr>
              <th>'. $x .'</th>
              <th>' . $custom_result->branch_name . '</th>
              <th><p style="color:#C9302C">' . $custom_result->sent_count . '</p></th>
              <th><p style="color:green">' . $custom_result->sent_count . '</p></th>
              
            </tr>
            ';

      }

    }


    echo $output;

}



#SEND SMS [ send_sms ]
if( Input::get('action') == _SEND_SMS ){

    $username = 'maggroup';
    $password = 'J@hn1654';
    $message  = Input::get('message');
    $msisdn   = Input::get('cell_number');    

    $api_url  = "http://bulksms.2way.co.za/eapi/submission/send_sms/2/2.0";

    $client   = curl_init($api_url);
    curl_setopt($client, CURLOPT_POST, true);
    curl_setopt($client, CURLOPT_POSTFIELDS, "username=$username&password=$password&message=$message&msisdn=$msisdn");
    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);  
    
    $response['server_response'] = curl_exec( $client );
    $curl_info = curl_getinfo( $client );
    $response['http_status'] = $curl_info[ 'http_code' ];
    $response['error'] = curl_error($client);
    curl_close( $client );
   
    $result = substr( $response['server_response'],0,1 );
    if( $result == 0 ){
      echo "SMS Sent Successfully";
    }else{
      echo "SMS Failed To Send!";
    }
    



}



#SEND EMAIL [ send_email ]
if( Input::get('action') == _SEND_EMAIL ){
     
      $email    = Input::get('email'); 
      $message  = Input::get('email_message');
      $output   = '';
      
      $validate = new Validate();
      $validate = $validate->check( $_POST, array(
          
          'email' => array(

            'required' => true,
            'min'      => 2,
            'max'    => 100,
            'valid_email'  => true
            
          )
          

      ) );


      #VALIDATE
      if( $validate->passed() ){
          #send email

            $mail = new PHPMailer();
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->Port = 587;
            $mail->SMTPSecure = 'tls';
            $mail->SMTPAuth = true;
            $mail->Username = "mag.accounzi2018@gmail.com";
            $mail->Password = "123coded";
            $mail->setFrom("mag.accounzi2018@gmail.com", 'Advanced Intelligence System');
            $mail->addReplyTo('info@motoraccidentgroup.co.za', 'Advanced Intelligence System');

            $mail->addAddress( $email , '');
            $mail->Subject = 'Advanced Intelligence System Notification';
            $mail->AltBody    = "";
            $mail->Body = $message;

            if (!$mail->send()) {
                //echo 0;
                echo "Mailer Error: " . $mail->ErrorInfo;
            }else{

                echo "Emails Sent Successfully";

            }
    

      }else{

          #Output errorrs
          foreach( $validate->errors() as $error ){
            //echo $error . "<br/>";
             $output .= $error;
             echo  $output;

          }
      
      }


}

?>
