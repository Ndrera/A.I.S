<?php
require_once 'core/init.php';
require 'PHPMailer_5.2.1/class.phpmailer.php';
//include 'automate.php';

$auto = new Automate();
//$auto->Automate();



$user = new User();
if( !$user->isLoggedIn() ){
 	//Redirect::to('index.php');
 	Redirect::to('login.php');
}


?>

<!DOCTYPE html>
<html>
<head>
	<title>A.I.S</title>
	<meta name="viewport" content="width=device-width, initial-sacle=1">
	<script type="text/javascript" src="js/jquery.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/custom.css">
	<script type="text/javascript" src="js/bootstrap.min.js"></script>

	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

	<style type="text/css">
			.border-color{
				border:2px solid #69C3DE !important;
			}

			.iconic-color{
				color: #E82F3E;
				font-size:18px;
			}

			.icon-red{
				color: red;
				font-size:18px;
			}

			.icon-yellow{
				color: #FAB43F;
				font-size:18px;

			}

			.icon-cream{
				color: #7CFC00;
				font-size:18px;

			}

			.icon-darkorange{
				color: #FF7500;
				font-size:18px;
			}

			.icon-intensered{
				color: #CC2900;
				font-size:18px;
			}

			.icon-ligthgreen{
				color: #F67656;
				font-size:18px;
			}


	</style>


</head>
<body style="background-color: #F0EBDF !important;">

	<!-- # NAV -->
	<?php include 'includes/layout/nav.php'; ?>

	<!-- # CONTAINER -->
     <div style="padding-right: 40px !important; padding-left: 40px !important;">
			    <p>
					<div class="well border-color">

					<!-- # WELL <div class="well"> -->
						  
						 
						
					    <table class="table">
						 		<thead class="thead-dark">
						 			<tr>

						 				<th colspan="2"><h3>Manage Notifications: <img src="images/icon1.png" class="img-fluid" alt="" width="80" height="60"> </h3>  </th>

						 			</tr>
						 		</thead>

						 		<tbody>

						 			
						 			<tr>
						 				<td>
						 					<button type="button" name="remaining_credits" id="remaining_credits" class="btn btn-success btn-block">Remaining Credits <span class="glyphicon glyphicon-equalizer"></span> </button>
						 				</td>

						 				<td>
						 					<button type="button" name="sent_smses" id="sent_smses" class="btn btn-info btn-block">Sent SMS <span class="glyphicon glyphicon-comment"></span> &#38; Email <span class="glyphicon glyphicon-envelope"></span></button>
						 				</td>
						 			</tr>

						 			<tr>
						 				<td>
						 					
						 					<button type="button" name="sent_email" id="sent_email" class="btn btn-danger btn-block">Send Email <span class="glyphicon glyphicon-send"></span> </button>

						 				</td>

						 				<td>
						 					<button type="button" name="send_sms" id="send_sms" class="btn btn-warning btn-block">Send SMS <span class="glyphicon glyphicon-phone"></span> </button>
						 				</td>

						 			</tr>	
									

						 		</tbody> 

						 		
						 </table>


						 <ul class="list-group">
					   	 <li class="list-group-item">

					   	 
					   	 <img class="img-fluid img-rounded" src="images/bi2.png" style="width: 100%;height: 95px;">

					   	 <hr/>
					   	 


					   	 <!-- #NAVIGATION BUTTON -->

					   	 <div id="success_msg" class="text-center">
					 
					   	 </div>

					   	 <div id="results" class="text-center">
					 
					   	 </div>
					   	
					   
						 <form action="" method="post" id="search_form">

						 	<div class="table-responsive">

						 	<table class="table">


							  <thead class="thead-dark">
							    <tr id="show_title">

							      <th class="success" scope="col"><center>Remaining Credits</center></th>

							    </tr>
							  </thead>

							  <tbody id="show_body">

							  	
							  	<tr>
							  	 <th>
							  	 	<!--
							  	 	<button type="button" name="output" id="output" class="btn btn-primary btn-block output" style="height: 100px;"></button>
							  	 	-->

							  	 	<button type="button" name="output" id="output" class="btn btn-primary btn-block output" style="height: 150px;"></button>
							  	 </th>
							  	
							  	</tr>
							  	

							  </tbody>

							</table>

						</div>

						
					   	  	
					   	  </form>

					   	 </li>
					   	 </ul>

					</div>
				</p>

	 </div>
			



	<!-- # FOOTER -->
	<footer class="footer navbar-fixed-bottom text-center">
		<p>Copyright <?php echo date('Y'); ?> &copy; A.I.S </p>
	</footer>

</body>
</html>


<!-- SEND SMS MODAL  -->
<div id="send_sms_modal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			
			<form method="post" id="send_sms_form">
				
				<div class="modal-header" style="background-color: #69C3DE !important;">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Send SMS</h4>
				</div>
				<!-- Modal Body-->
				<div class="modal-body">

					<div class="form-group">
						<label id="lbl">Cell Number (s):   e.g[ +27764541234,+27601151234   ]</label>
						<input type="text" name="cell_number" id="cell_number" class="form-control border-color" required />
					</div>

			
					<div class="form-group">
						<label>Message:</label>
						<textarea type="text" name="message" id="message" class="form-control border-color" required ></textarea>

					</div>

				</div>
				<!-- Modal Footer -->
				<div class="modal-footer" style="background-color: #69C3DE !important;">
					<input type="hidden" name="hidden_id" id="hidden_id" />

					<input type="hidden" name="action" id="action" value="send_sms" />

					<input type="submit" name="send" id="send" class="btn btn-success" value="Send" />


					<button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>

				</div>

			</form>

		</div>
	</div>
</div>


<!-- SEND EMAIL MODAL  -->
<div id="send_email_modal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			
			<form method="post" id="send_email_form">
				
				<div class="modal-header" style="background-color: #69C3DE !important;">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Send Email</h4>
				</div>
				<!-- Modal Body-->
				<div class="modal-body">

					<div class="form-group email_show">
						<label>Email Address:</label>
						<input type="text" name="email" id="email" class="form-control border-color" required />
					</div>
					

					<div class="form-group">
						<label>Message:</label>
						<textarea type="text" name="email_message" id="email_message" class="form-control border-color" required ></textarea>

					</div>

				</div>
				<!-- Modal Footer -->
				<div class="modal-footer" style="background-color: #69C3DE !important;">
					<input type="hidden" name="hidden_id" id="hidden_id" />

					
					<input type="hidden" name="action" id="action" value="send_email" />
				

					<input type="submit" name="send" id="send" class="btn btn-success" value="Send" />


					<button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>

				</div>

			</form>

		</div>
	</div>
</div



<!-- SCRIPTS -->
<script type="text/javascript">
$(document).ready( function(){

	//NOTE THESE ARE CLIENTS
	fetch_data();

	function fetch_data(){

		$.ajax({
			url:"credits.php",
			success:function(data){

				//$('#show_body').html('<tr><th><button type="button" name="output" id="output" class="btn btn-primary btn-block output" style="height: 100px;"></button></th></tr>');
				$('#output').html("<h1>" + data + "</h1>");


			}
		})
	}


	//REMAINING CREDITS
	$(document).on('click', '#remaining_credits', function(){

		 $('#show_title').html('<th class="success" scope="col"><center>Remaining Credits</center></th>');
		 $('#show_body').html('<tr><th><button type="button" name="output" id="output" class="btn btn-primary btn-block output" style="height: 150px;"></button></th></tr>');
		 fetch_data();

		 //location.reload();


	});


	//SENT SMSES
	$(document).on('click', '#sent_smses', function(){

		var action = "sent_smses"; 
		$.ajax({
			url:"api.php",
			method:"POST",
			data:{action:action},
			success:function(data){
		
				$('#show_title').html('<th class="success" scope="col">No</th><th class="success" scope="col">Client Name</th><th class="success" scope="col">Total SMSes Sent</th><th class="success" scope="col">Total Emails Sent</th>');
				$('#show_body').html( data );
				//location.reload(); 
				
			}

		});


	});



	//SEND SMSES
	$(document).on('click', '#send_sms', function(){
		$('.modal-title').text('Send SMS');
		$('#send_sms_modal').modal('show');

	});



    //#SEND SMS MODAL FORM
    $('#send_sms_form').on('submit', function(event){
		event.preventDefault();

		var form_data = $(this).serialize();
		$.ajax({
			url:"api.php",
			method:"POST",
			data:form_data,
			success:function(data){

				$('#send_sms_form')[0].reset(); //reset the form
				$('#send_sms_modal').modal('hide');
				alert( data );

				location.reload();

			}

		});
		
		
	});



    //SEND EMAIL
	$(document).on('click', '#sent_email', function(){
		$('.modal-title').text('Send Email');
		$('#send_email_modal').modal('show');

	});


    //#SEND SMS MODAL FORM
    $('#send_email_form').on('submit', function(event){
		event.preventDefault();

		var form_data = $(this).serialize();
		$.ajax({
			url:"api.php",
			method:"POST",
			data:form_data,
			success:function(data){

				$('#send_email_form')[0].reset(); //reset the form
				$('#send_email_modal').modal('hide');
				alert( data );

				location.reload();

			}

		});
		
				
	});



}); 

</script>