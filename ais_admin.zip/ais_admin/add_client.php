
<?php
require_once 'core/init.php';

$active = new User();
if( !$active->isLoggedIn() ){
 	//Redirect::to('index.php');
 	Redirect::to('login.php');
}


$user 		= new Branch();
$branch_add = new BranchAdditionals();

if( Input::exists() ){
	if( Token::check( Input::get('token') ) ){

		$output = "";

		$validate = new Validate();
		$validate = $validate->check( $_POST, array(
				
				'invoice_no' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50
					
				),
				'branch_name' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50
					
				),
				'branch_code' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50
					
				),
				'branch_contact' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50
					
				),
				'branch_email' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 60,
					'valid_email'  => true

					
				),
				'registered_name' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50
					
				),
				'emp_email' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 60,
					'valid_email'  => true
					
				),
				'emp_contact_number' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50
					
				),
				'address_line1' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50
					
				),
				'address_line2' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50
					
				),
				'address_line3' => array(

					'required' => true,
					'min' 	   => 2,
					'max'	   => 50
					
				),
				'address_line4' => array(

					'min' 	   => 2,
					'max'	   => 50
					
				)
				

		) );

	
		if( $validate->passed() ){

			try{
				#Create a new user
				$branch_last_id = DB::getInstance()->query("SELECT b.id FROM branch b ORDER BY id DESC LIMIT 1");

				if( !$branch_last_id->count() ){
				    #NO DATA FOUND IN THE DATABASE
					$output .= "
					<tr>
					    <td>Branch Last id failed to pull</td>
					</tr>
					";

				}else{
				   
					foreach( $branch_last_id->results() as $last ){
						$last->id;
					
					}

				}  

				$user->create( array(	

					'id'    			=> ++$last->id,
					'invoice_no'    	=> Input::get('invoice_no'),
					'branch_name'		=> Input::get('branch_name'),
					'branch_code'	  	=> Input::get('branch_code'),
					'branch_contact'	=>  Input::get('branch_contact'),
					'branch_email'      => Input::get('branch_email'),
					'branch_credits'    => 0,
					'credit_price'      => 35.00,
					'status'        	=> 1,
					'date_modified'     => date('Y-m-d')
					
				

				));


				$branch_add_last_id = DB::getInstance()->query("SELECT ba.id FROM branch_additionals ba ORDER BY id DESC LIMIT 1");

				if( !$branch_add_last_id->count() ){
				    #NO DATA FOUND IN THE DATABASE
					$output .= "
					<tr>
					    <td>Last id failed to pull</td>
					</tr>
					";

				}else{
				   
					foreach( $branch_add_last_id->results() as $ba_last ){
						$ba_last->id;
					
					}

				}  

				$branch_add->create(   array(	

					'id'    			   		=> ++$ba_last->id,
					'branch_id'    				=> $last->id,
					'registered_name'    		=> Input::get('registered_name'),
					'emp_email'		  			=> Input::get('emp_email'),
					'emp_contact_number'		=> Input::get('emp_contact_number'),
					'address_line1'	  			=> Input::get('address_line1'),
					'address_line2'	  			=> Input::get('address_line2'),
					'address_line3'	  			=> Input::get('address_line3'),
					'address_line4'        		=> Input::get('address_line4'),
					'credits_issued_to_date'    => 0

				) );

				Redirect::to('index.php');

			}catch( Exception $e ){
				die( $e->getMessage() );
			} 

		

		}else{

			#Output errorrs
			foreach( $validate->errors() as $error ){
				//echo $error . "<br/>";
				$output .= $error . '.<br/>';
				Session::put( 'output', "<div class='alert alert-danger'>" . $output . "</div>" );
			}
		

		}



	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>A.I.S</title>
	<meta name="viewport" content="width=device-width, initial-sacle=1">
	<script type="text/javascript" src="js/jquery.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/custom.css">
	<script type="text/javascript" src="js/bootstrap.min.js"></script>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

	<style type="text/css">
			.border-color{
				border:2px solid #69C3DE !important;
			}

			.iconic-color{
				color: #E82F3E;
				font-size:18px;
			}

			.icon-red{
				color: red;
				font-size:18px;
			}

			.icon-yellow{
				color: #FAB43F;
				font-size:18px;

			}

			.icon-cream{
				color: #7CFC00;
				font-size:18px;

			}

			.icon-darkorange{
				color: #FF7500;
				font-size:18px;
			}

			.icon-intensered{
				color: #CC2900;
				font-size:18px;
			}

			.icon-ligthgreen{
				color: #F67656;
				font-size:18px;
			}


	</style>



</head>
<body style="background-color: #F0EBDF !important;">

	<!-- # NAV -->
	<?php include 'includes/layout/nav.php'; ?>


	<!-- # CONTAINER -->
	<div class="container container-bg">
		<div class="row">

			<div class="col-md-12">
			    <p>
					<div class="well border-color">

						 <div id="results" class="text-center">
					 		 <?php
					 		   if( Session::exists('output') ){
					 		   	   echo  Session::flash('output');

								}
					 		 ?>
					   	 </div>

						 <!-- ADD THE TABLE OUTSIDE -->
						 <table class="table">
						 		<thead class="thead-dark">
						 			<tr>

						 				<th colspan="2" ><h3>Add New Client:   <img src="images/icon7.png" class="img-fluid" alt="" width="65" height="65"> </h3></th>

						 			</tr>
						 		</thead>

						 		

						</table>



						 <ul class="list-group">
					   	 <li class="list-group-item">


					   	 <!-- #ADD IMAGE HERE-->
					   	 <img class="img-fluid img-rounded" src="images/bi2.png" style="width: 100%;height: 95px;">
					   	
						 <!-- <hr/> -->
				
						 <form action="" method="post" id="register_form">

						 	<table class="table">

						 		<thead class="thead-dark">
						 			<tr>
						 				<th colspan="2" ></th>
						 			</tr>
						 		</thead>

						 		<tbody>
						 			<tr>

						 				<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Invoice No:</label>
							   	  	 			
							   	  	 			<input type="text" name="invoice_no" id="invoice_no" value="<?php echo escape( Input::get('invoice_no') ); ?>" class="form-control border-color">
							   	  	 	
							   	  	 		</div>
							   	  	 	</td>

							   	  	 	<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Company Name:</label>
							   	  	 			<input type="text" name="branch_name" id="branch_name"  value="<?php echo escape( Input::get('branch_name') ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

						 			</tr>

						 			<tr>
						 				<td colspan="2">
						 					<div class="form-group">
							   	  	 			<label>Company Code:</label>
							   	  	 			<input type="text" name="branch_code" id="branch_code"  value="<?php echo escape( Input::get('branch_code') ); ?>" class="form-control border-color">
							   	  	 		</div>
						 				</td>
						 			</tr>

						 			
						 			<tr>

						 				<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Contact No:</label>
							   	  	 			<input type="text" name="branch_contact" id="branch_contact" value="<?php echo escape( Input::get('branch_contact') ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

							   	  	 	<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Email:</label>
							   	  	 			<input type="text" name="branch_email" id="branch_email"  value="<?php echo escape( Input::get('branch_email') ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

						 			</tr>

									
						 			<tr>

						 				<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Registered Name:</label>
							   	  	 			<input type="text" name="registered_name" id="registered_name" value="<?php echo escape( Input::get('registered_name') ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

							   	  	 	<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Employee Email:</label>
							   	  	 			<input type="text" name="emp_email" id="emp_email"  value="<?php echo escape( Input::get('emp_email') ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

						 			</tr>


						 			<tr>

						 				<td colspan="2">
							   	  	 		<div class="form-group">
							   	  	 			<label>Employee Contact No:</label>
							   	  	 			<input type="text" name="emp_contact_number" id="emp_contact_number" value="<?php echo escape( Input::get('emp_contact_number') ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

							   	  	</tr>


						 			<tr>


							   	  	 	<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Address Line 1:</label>
							   	  	 			<input type="text" name="address_line1" id="address_line1"  value="<?php echo escape( Input::get('address_line1') ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

							   	  	 	<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Address Line 2:</label>
							   	  	 			<input type="text" name="address_line2" id="address_line2" value="<?php echo escape( Input::get('address_line2') ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

						 			</tr>


						 			<tr>

							   	  	 	<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Address Line 3:</label>
							   	  	 			<input type="text" name="address_line3" id="address_line3"  value="<?php echo escape( Input::get('address_line3') ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

							   	  	 	<td>
							   	  	 		<div class="form-group">
							   	  	 			<label>Address Line 4 :</label>
							   	  	 			<input type="text" name="address_line4" id="address_line4" value="<?php echo escape( Input::get('address_line4') ); ?>" class="form-control border-color">
							   	  	 		</div>
							   	  	 	</td>

						 			</tr>
						 			

						 			<tr>
							   	  	 	<td colspan="2">
							   	  	 		<div class="form-group">
							   	  	 		    <input type="hidden" name="token" value="<?php echo Token::generate(); ?>">
							   	  	 			<input type="hidden" name="action" id="action" value="" >
							   	  	 			<input type="submit" name="register" id="register" value="Add Client" class="btn btn-primary btn-block">
							   	  	 		</div>
							   	  	 	</td>
							   	  	 </tr>

						 		</tbody>
						 	</table>
					   	  	
					   	  </form>

					   	 </li>
					   	 </ul>

					</div>
				</p>
			</div>			

		</div>
	</div>

	<!-- # FOOTER -->
	
	<footer class="footer navbar-fixed-bottom text-center">
		<p>Copyright <?php echo date('Y'); ?> &copy; A.I.S</p>
	</footer>

</body>
</html>

<!-- Search for People -->
<script type="text/javascript">
$(document).ready( function(){
        
	//ADD HERE, MAYBE IF I CHOOSE TO VALIDATE THIS SIDE


} );

</script>