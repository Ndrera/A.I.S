<?php
require_once 'core/init.php';

$user = new User();
if( !$user->isLoggedIn() ){
 	Redirect::to('login.php');
}



?>
<!DOCTYPE html>
<html>
<head>
	<title>A.I.S</title>
	<meta name="viewport" content="width=device-width, initial-sacle=1">
	<script type="text/javascript" src="js/jquery.js"></script>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/custom.css">
	<script type="text/javascript" src="js/bootstrap.min.js"></script>

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

	<style type="text/css">
			.border-color{
				border:2px solid #69C3DE !important;
			}

			.iconic-color{
				color: #E82F3E;
				font-size:18px;
			}

			.icon-red{
				color: red;
				font-size:18px;
			}

			.icon-yellow{
				color: #FAB43F;
				font-size:18px;

			}

			.icon-cream{
				color: #7CFC00;
				font-size:18px;

			}

			.icon-darkorange{
				color: #FF7500;
				font-size:18px;
			}

			.icon-intensered{
				color: #CC2900;
				font-size:18px;
			}

			.icon-ligthgreen{
				color: #F67656;
				font-size:18px;
			}


	</style>



</head>
<body style="background-color: #F0EBDF !important;">

	<!-- # NAV -->
	<?php include 'includes/layout/nav.php'; ?>

	<!-- # CONTAINER -->
	<div style="padding-right: 40px !important; padding-left: 40px !important;">

	    <p>
			<div class="well border-color">

				  <table class="table">
				 		<thead class="thead-dark">
				 			<tr>
				 				
				 				<th colspan="2" ><h3>Billing:  <img src="images/icon9.png" class="img-fluid" alt="" width="80" height="60"> </h3></th>

				 			</tr>
				 		</thead>

				 </table>

				 <ul class="list-group">
			   	 <li class="list-group-item">
			   	  <img class="img-fluid img-rounded" src="images/bi2.png" style="width: 100%;height: 95px;">
			   	

				 <hr/>

			   	 <div id="results" class="text-center">
			 		
			   	 </div>
			   	
			   	<div class="form-group">
   	  	 			<label>SELECT CREDITS:</label>

   	  	 			 <select name="load_credit" id="load_credit" class="form-control" style="border:2px solid #FF0000;">
   	  	 			 	<option value="0">Select Credits</option>
					  	<option value="10">10</option>
					  	<option value="20">20</option>
					  	<option value="30">30</option>
					  	<option value="40">40</option>
					  	<option value="50">50</option>
					  	<option value="60">60</option>
					  	<option value="70">70</option>
					  	<option value="80">80</option>
					  	<option value="90">90</option>
					  	<option value="100">100</option>
						<option value="150">150</option>
						<option value="200">200</option>							  	
					 </select>

				</div>


				 <form action="" method="post" id="credit_form">
				 							 
				 	<div class="table-responsive">
				 	<table class="table">
				 	
						<thead class="black white-text"> 
				 			<tr>
				 	
				 				<th class="success" scope="col">NO</th>
						        <th class="success" scope="col">Client Name</th>
						        <th class="success" scope="col">Available Credit</th>
						    	<th class="success" scope="col">Approved Credits</th>
						        <th class="success" scope="col">Approve</th>
						        <th class="success" scope="col">Confirm Payment</th>
						        <th class="success" scope="col">Payment</th>
						        <th class="success" scope="col">Auth</th>
						        <th class="success" scope="col">Status</th>
						        <th class="success" scope="col">Date Modified</th>
						        <th class="success" scope="col">Invoice</th>
						        <th class="success" scope="col">Statement</th>

				 			</tr>
				 		</thead>

				 		
				 		<tbody id="bills_output"></tbody>

				 		<tbody id="invoice_output"></tbody>
				 		

				 	</table>
				 </div>
				   

			   	  	
			   	  </form>

			   	 </li>
			   	 </ul>

			</div>
		</p>
					
	</div>
	

	<!-- # FOOTER -->
	<footer class="footer navbar-fixed-bottom text-center">
		<p>Copyright <?php echo date('Y'); ?> &copy; A.I.S</p>
	</footer>

</body>
</html>

<!-- #MODAL FOR INVOICE AND STATEMENT 
-->
<div id="billModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			
			<form method="post" id="invoice_form">
				
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Pull Invoice</h4>
				</div>
				<!-- Modal Body-->
				<div class="modal-body">

					<div class="form-group">
						<label>Date From:</label>
						<input type="date" name="date_from" id="date_from" class="form-control" required />
					</div>
					<div class="form-group">
						<label>Date To:</label>
						<input type="date" name="date_to" id="date_to" class="form-control" required />
					</div>

				</div>
				<!-- Modal Footer -->
				<div class="modal-footer">
					<input type="hidden" name="hidden_id" id="hidden_id" />

					<input type="hidden" name="action" id="action" value="insert" />

					<input type="submit" name="print_invoice" id="print_invoice" class="btn btn-info" value="Print" />


					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

				</div>

			</form>

		</div>
	</div>
</div>

<!-- #MODAL STATEMENT -->
<div id="statementModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			
			<form method="post" id="statement_form">
				
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Pull Statement</h4>
				</div>
				<!-- Modal Body-->
				<div class="modal-body">


					<div class="form-group">
						<label>Date From:</label>
						<input type="date" name="statement_date_from" id="statement_date_from" class="form-control" required />
					</div>
					<div class="form-group">
						<label>Date To:</label>
						<input type="date" name="statement_date_to" id="statement_date_to" class="form-control" required />
					</div>

				</div>
				<!-- Modal Footer -->
				<div class="modal-footer">
					<input type="hidden" name="statement_hidden_id" id="statement_hidden_id" />

					<input type="hidden" name="action" id="action" value="insert" />

					
					<input type="submit" name="print_statement" id="print_statement" class="btn btn-info" value="Print" />


					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

				</div>

			</form>

		</div>
	</div>
</div>


<script type="text/javascript">
$(document).ready( function(){

	fetch_data();

	function fetch_data(){

		var action = 'fetch_billing';
		$.ajax({
			url:"fetch.php",
			success:function(data){

				$('#bills_output').html(data);
			}
		})
	}

	
	/* INVOICE */
	//#INVOICE   
	$(document).on('click', '.invoice', function(){

		var id = $(this).attr('id');
		$('#hidden_id').val(id);
		$('#billModal').modal('show');
	    

	});


	$('#invoice_form').on('submit', function(event){
		event.preventDefault();
			
			var date_from = $('#date_from').val();
			var date_to = $('#date_to').val();
			var my_id = $('#hidden_id').val();
			var action = "invoice";
			$.ajax({
				url:"action.php",
				method:"POST",
				data:{id:my_id, date_from:date_from, date_to:date_to, action:action },
				success:function(data){

					$('#billModal').modal('hide');
					$('#invoice_form')[0].reset(); 

					if( data == 0 ){
						alert("No invoices were gerenated for this dates");

					}else if( data == 1 ){
                         window.open("invoice.php?id=" + my_id + "&from=" + date_from + "&to=" + date_to);

					}

									
				},
				async: false

			});

		



	});


	

	
	/* STATEMENT */
	//#STATEMENT
	$(document).on('click', '.statement', function(){

		var statement_id = $(this).attr('id');
		$('#statement_hidden_id').val(statement_id);
		$('#statementModal').modal('show');   //DATES FORM
		
	});


	$('#statement_form').on('submit', function(event){
		event.preventDefault();
			
			var date_from = $('#statement_date_from').val();
			var date_to = $('#statement_date_to').val();
			var id = $('#statement_hidden_id').val();
			var action = "statement";
			$.ajax({
				url:"action.php",
				method:"POST",
				data:{id:id, date_from:date_from, date_to:date_to, action:action },
				success:function(data){

					$('#statementModal').modal('hide');
					$('#statement_form')[0].reset(); 

					if( data == 0 ){
						alert("No statements were gerenated for this dates");

					}else if( data == 1 ){
                         window.open("statement.php?id=" + id + "&from=" + date_from + "&to=" + date_to);

					}
										
				},
				async: false

			});

		});



	    /* APPROVE CREDIT */
		//#APPROVE CREDIT
		$(document).on('click', '.approve', function(){

			var value = $( "#load_credit option:selected" ).val();
			if( value == 0 ){
				alert('Please select credits.');
				location.reload();
				return;
			}//else{}
    	   
        	var approve_id = $(this).attr('id');
        	var action = "approve";
			$.ajax({
				url:"action.php",
				method:"POST",
				data:{approve_id:approve_id, value:value, action:action},
				success:function(data){					
					
					alert(data);
					window.open("current_invoice.php?id=" + approve_id);
					location.reload(); 
					
					
				},
				async: false

			});

			
		});


		/* CONFIRM PAYMENT */
		//CONFIRM PAYMENT
		$(document).on('click', '.confirm', function(){

			if( confirm("Are you sure you want to confirm payment?") ){
	
	        	var confirm_id = $(this).attr('id');
	        	var action = "confirm";
				$.ajax({
					url:"action.php",
					method:"POST",
					data:{confirm_id:confirm_id, action:action},
					success:function(data){

						alert(data);
						location.reload(); 
						
					}

				});

			}
				

		});


		/* ACTIVATE */
		//ACTIVATE
		$(document).on('click', '.activate', function(){	
			
        	var activate_id = $(this).attr('id');
        	var action = "activate";
			$.ajax({
				url:"action.php",
				method:"POST",
				data:{activate_id:activate_id, action:action},
				success:function(data){
					
					alert(data);
					location.reload(); 		
						
				}

			});
			
		});


} );

</script>