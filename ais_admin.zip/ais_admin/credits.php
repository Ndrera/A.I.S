<?php
require_once 'core/init.php';

$username = 'maggroup';
$password = 'J@hn1654';

$api_url = "http://bulksms.2way.co.za/eapi/user/get_credits/1/1.1?username=maggroup&password=J@hn1654";

$client = curl_init($api_url);
curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

//curl_setopt ( $client, CURLOPT_TIMEOUT, 20 );
//curl_setopt ( $client, CURLOPT_CONNECTTIMEOUT, 10 );

$response = curl_exec($client);
$result = $response;
echo substr( $result, 2);


?>
