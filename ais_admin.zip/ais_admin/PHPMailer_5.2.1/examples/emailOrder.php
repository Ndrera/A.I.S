<?php

//error_reporting(E_ALL);
error_reporting(E_STRICT);
include_once 'dbConfig.php'; 
//date_default_timezone_set('America/Toronto');
$id = $_POST['deleteOrderPartsFormtxtId_em'];
$sql = "select * from confirmed_orders where id ='$id'";
$result = mysqli_query($db, $sql) or die("Error in Selecting " . mysqli_error($db));
$email='';
$emailTo='';
$attchmnt='';
while($row =mysqli_fetch_assoc($result))
{
    $emailTo = $row['address'];
    $email = $row['user_email'];
    $attchmnt = $row['url'];
}
require_once('../class.phpmailer.php');
//include("class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded

$mail                = new PHPMailer();
$mail->isSMTP();
//Enable SMTP debugging
// 0 = off (for production use)
// 1 = client messages
// 2 = client and server messages
//$mail->SMTPDebug = 2;
//Ask for HTML-friendly debug output
//$mail->Debugoutput = 'html';
$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPSecure = 'tls';
$mail->SMTPAuth = true;
$mail->Username = "mag.accounzi2018@gmail.com";
$mail->Password = "123coded";
$mail->setFrom($email, 'Motor Accident Group');
$mail->addReplyTo('info@motoraccidentgroup.co.za', 'Motor Accident Group');
$mail->addAddress($emailTo, '');
$mail->Subject = 'M.A.G Order';
$mail->msgHTML(file_get_contents('contents.html'), dirname(__FILE__));
$mail->AltBody = '';
$mail->addAttachment('../../models/tcpdf/examples/Orders/'.$attchmnt);
if (!$mail->send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
} else {
    $sqla = "UPDATE `confirmed_orders` SET `mail_status`='Sent' WHERE `id`='$id'";
    mysqli_query($db, $sqla);
    echo 0;
}