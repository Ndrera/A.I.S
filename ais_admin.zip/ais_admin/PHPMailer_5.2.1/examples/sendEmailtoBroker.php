<?php

//error_reporting(E_ALL);
error_reporting(E_STRICT);
include_once 'dbConfig.php'; 
//date_default_timezone_set('America/Toronto');
$msg = $_POST['msg'];
$ttle = $_POST['ttle'];
$email = $_POST['email'];
$reg = $_POST['reg'];
//$sql = "select * from confirmed_orders where id ='$id'";
//$result = mysqli_query($db, $sql) or die("Error in Selecting " . mysqli_error($db));
//$email='';
//$emailTo='';
//$attchmnt='';
//while($row =mysqli_fetch_assoc($result))
//{
//    $emailTo = $row['address'];
//    $email = $row['user_email'];
//    $attchmnt = $row['url'];
//}
require_once('../class.phpmailer.php');
//include("class.smtp.php"); // optional, gets called from within class.phpmailer.php if not already loaded

$mail                = new PHPMailer();
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPSecure = 'tls';
$mail->SMTPAuth = true;
$mail->Username = "mag.accounzi2018@gmail.com";
$mail->Password = "123coded";
$mail->setFrom("mag.accounzi2018@gmail.com", 'Motor Accident Group');
$mail->addReplyTo('info@motoraccidentgroup.co.za', 'Motor Accident Group');
$mail->addAddress($email, '');
$mail->Subject = 'M.A.G WORK IN PROGRESS';

$mail->Subject    = 'Progress For: '.$reg;
$mail->AltBody    = "";
$mail->MsgHTML($msg);
//$mail->addAttachment('../../models/tcpdf/examples/Orders/'.$attchmnt);
if (!$mail->send()) {
    echo 1;
} else {
//    $sqla = "UPDATE `confirmed_orders` SET `mail_status`='Sent' WHERE `id`='$id'";
//    mysqli_query($db, $sqla);
    echo 0;
}