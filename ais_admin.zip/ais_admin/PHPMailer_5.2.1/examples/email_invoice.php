<?php
error_reporting(E_STRICT);
include_once 'dbConfig.php'; 

require_once('../class.phpmailer.php');
/*
$id = $_POST['id'];

$dbcmd   = "select * from branch where id='$id'";
$dbquery = $db->query($dbcmd);

if($dbquery->num_rows>0){
while($dbrow=$dbquery->fetch_assoc()){

$invoice_no = $dbrow['invoice_no'];
$branch_email = $dbrow['branch_email'];
	
}	
}

if($id==1){
$code = "MS";	
}

if($id==2){
$code = "ML";	
}

if($id==3){
$code = "MGC";	
}

if($id==4){
$code = "ME";	
}

$file_name = $code.$invoice_no;
*/
$mail                = new PHPMailer();
$mail->isSMTP();
$mail->Host = 'smtp.system-ais.com';
$mail->Port = 465;
$mail->SMTPSecure = 'tls';
$mail->SMTPAuth = true;
$mail->Username = "support@system-ais.com";
$mail->Password = "Sy3t3m@!$";
$mail->setFrom('info@motoraccidentgroup.co.za', 'Advanced Intelligent System');
$mail->addReplyTo('info@motoraccidentgroup.co.za', 'Motor Accident Group');
$mail->addAddress('webdesigner@motoraccidentgroup.co.za', '');
//$mail->addCC('john@motoraccidentgroup.co.za');
//$mail->addCC('procurement@motoraccidentgroup.co.za');
//$mail->addCC('mag@motoraccidentgroup.co.za');
//$mail->addCC($branch_email);
$mail->Subject = 'Advanced Intelligent System';
$mail->msgHTML(file_get_contents('contents.html'), dirname(__FILE__));
$mail->AltBody = 'xxxxxxxxxxxxxxxxxxxxxx';
//$mail->addAttachment('../../models/tcpdf/examples/billing_invoice/'.$file_name.'.pdf');

if (!$mail->send()) {
echo "Mailer Error: " . $mail->ErrorInfo;
} else {
echo ("SENT");
}
?>