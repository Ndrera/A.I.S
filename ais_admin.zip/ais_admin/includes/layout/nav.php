<nav class="nav navbar-inverse">
		<div class="container">
			
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				<a class="navbar-brand" href="index.php">Advanced Intelligence System</a>
			</div>

			<!-- style="font-size:50px;color:blue" -->

			<div id="navbar" class="collapse navbar-collapse">
				<ul class="nav navbar-nav" id="_links">

					<li class=""><a href="index.php">Home <span class="glyphicon glyphicon-home icon-yellow"></span></a></li>
					<li class=""><a href="register.php">Add User <span class="glyphicon glyphicon-user icon-ligthgreen"></span></a></li>
					<li class=""><a href="add_client.php">Add Client <span class="glyphicon glyphicon-tasks icon-cream"></span> </a></li>
					<li class=""><a href="billing.php">Billing <span class="glyphicon glyphicon-credit-card icon-darkorange"></span> </a></li>
					<li class=""><a href="manage.php">Manage Notifications <span class="glyphicon glyphicon-calendar icon-intensered"></span> </a></li>
					<li class=""><a href="logout.php">Logout <span class="glyphicon glyphicon-off icon-red"></span> </a></li>

				</ul>
			</div>

		</div>
</nav>