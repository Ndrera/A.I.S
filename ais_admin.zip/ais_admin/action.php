<?php
//action.php

require_once 'core/init.php';
//require('fpdf182/fpdf.php');

const _INVOICE   = 'invoice';
const _STATEMENT = 'statement';
const _APPROVE   = 'approve';
const _CONFIRM   = 'confirm';
const _ACTIVATE  = 'activate'; 
const _SUSPEND   = 'suspend';


#INVOICE AND STATTEMENT
if( Input::get('action') == _INVOICE  || Input::get('action') == _STATEMENT ){
	#check if the requested invoice was created
	$output = '';

	$id 	    = Input::get('id');                #NOTE:IT'S    credit_id
	$date_from  = Input::get('date_from');   	   #Date from the form field  
	$date_to    = Input::get('date_to');


	$custom 	= new CustomsBranch();
	if( $custom->find($id ) ){
		//echo "CUSTOMS";
		$db = CustomsDB::getInstance();

	}else{
		$db = DB::getInstance();
	}


	$data = $db->query("SELECT * FROM branch_invoice bi 
		INNER JOIN branch_invoice_additionals bia ON bi.id = bia.branch_invoice_id 
		WHERE (bi.date_invoiced BETWEEN '$date_from' AND '$date_to') AND bi.branch_id = $id");


	if( !$data->count() ){

		$old_invoice = $db->query("SELECT * FROM branch_invoice bi 
			WHERE (bi.date_invoiced BETWEEN '$date_from' AND '$date_to') AND bi.branch_id = $id");

		if( !$old_invoice->count()  ){
			echo "0";
		}else{
			echo "1";
		}


	}else{
		echo "1";

	}

	echo $output;

}



#APPROVE
if( Input::get('action') == _APPROVE ){

	$branch_id = Input::get('approve_id');
	$credit    = Input::get('value');  //Drowdown Selected value

	$custom    = new CustomsBranch();
	if( $custom->find($branch_id ) ){
		//echo "CUSTOMS";
		$db = CustomsDB::getInstance();
	}else{

		$db = DB::getInstance();

	}

	$data = $db->query("SELECT b.invoice_no, b.credit_price, b.branch_name, b.branch_credits, b.credit_price, ba.credits_issued_to_date, 
		ba.id, ba.address_line1, ba.address_line2, ba.address_line3, ba.address_line4 
		FROM branch b 
		INNER JOIN branch_additionals ba ON b.id = ba.branch_id 
		WHERE b.id =" . $branch_id);


	$output = '';
	if( !$data->count() ){
	    #NO DATA FOUND IN THE DATABASE
		$output .= "
		<tr>
		    <td>This client is not found in our records</td>
		</tr>
		";

	}else{
	   
		foreach( $data->results() as $result ){
			$result->branch_name;
			$result->branch_credits;
			$result->credits_issued_to_date;
			$result->id;
		
		}


		try{
			#UPDATE THE CREDIT  
			$db->update( 'branch', $branch_id, array(	
				'date_modified' 		=> date('Y-m-d')
				
			) );

			#GET THE branch_additionals = id
			$db->update( 'branch_additionals', $result->id, array(
				'loaded_credits'  			=> $credit,	
				'payment'					=> "Pending"

			) );


		}catch( Exception $e ){
			die( $e->getMessage() );
		} 


	}



	#INVOICE
	#SAVING DATA INTO THE TB INVOICE
	$total_price 	= ($credit * $result->credit_price);

	$date_invoiced 	= date('Y-m-d'); 

	$sales_rep 		= "A.I.S";

	$description 	= "Advanced Intelligence System";

	$time			= strtotime( date("Y-m-d") );
	$due_date 		= date("Y-m-d", strtotime("+1 week", $time));

	$invoice_num    = ""; 
	$custom_invoice_num  = "";


	try{
		#Create a new invoice
		
		$data_id = $db->query("SELECT id FROM branch_invoice ORDER BY id DESC LIMIT 1");
		if( !$data_id->count() ){
			#NO DATA FOUND IN THE DATABASE
			echo "No invoice data found";

		}else{

			 $x = 1;
			foreach( $data_id->results() as $result_inv ){
				$result_inv->id;
			}

		}

		#NOTE: I am setting invoice_no to ZERO (0) To make it not confict with the incrementing invoice no
		$save = $db->insert( 'branch_invoice', array(	
				
			'id'    		    => ++$result_inv->id,		
			'branch_id'    		=> $branch_id,
			'invoice_no'		=> 0,
			'quantity'	  		=> $credit,
			'unit_price'		=> $result->credit_price,
			'total_price'       => $total_price,
			'date_invoiced' 	=> $date_invoiced
			

		) );


		#Latest invoice_no and increment
		#add to AISI to [ invoice_reference  ]
		#MAG LIVE SERVER
		$invoices = DB::getInstance()->query("SELECT invoice_no FROM branch_invoice_additionals ORDER BY invoice_no DESC LIMIT 1");
		if( !$invoices->count() ){
			#NO DATA FOUND IN THE DATABASE
			$invoice_value = 100756;

		}else{

			foreach( $invoices->results() as $invoice ){
				//$invoice->invoice_no;
				$invoice_num    = $invoice->invoice_no; 
	
			}

		} 


		#MAG CUSTOMS
		$custom_invoices = CustomsDB::getInstance()->query("SELECT invoice_no FROM branch_invoice_additionals ORDER BY invoice_no DESC LIMIT 1");
		if( !$custom_invoices->count() ){
			#NO DATA FOUND IN THE DATABASE
			$invoice_value = 100756;

		}else{

			foreach( $custom_invoices->results() as $custom_invoice ){
				//$custom_invoice->invoice_no;
				$custom_invoice_num  = $custom_invoice->invoice_no;

			}

		} 


		#GREATER THAN
		if( $invoice_num  >  $custom_invoice_num  ){
			$invoice_value = ++$invoice_num ;

		}else if( $custom_invoice_num  > $invoice_num ){
			$invoice_value = ++$custom_invoice_num ;
		}

		#$invoice_value = ( $invoice_num  >  $custom_invoice_num ) ? ++$invoice_num : ++$custom_invoice_num;


		
		$save = $db->insert( 'branch_invoice_additionals', array(	
						
			'branch_invoice_id'    	 	=> $result_inv->id,
			'sales_rep'        			=> $sales_rep,
			'invoice_no'				=> $invoice_value,
			'invoice_reference'    		=> "AISI" . $invoice_value,
			'recipient_address_line1'   => $result->address_line1,
			'recipient_address_line2'   => $result->address_line2,
			'recipient_address_line3'   => $result->address_line3,
			'recipient_address_line4'   => $result->address_line4,
			'description'        		=> $description,
			'due_date'        			=> $due_date

			

		) );

	    echo "Credits Approved";
		

	}catch( Exception $e ){
		die( $e->getMessage() );
	} 


}



#CONFIRM
if( Input::get('action') == _CONFIRM ){

	$id = Input::get('confirm_id'); 

	$custom 	= new CustomsBranch();
	if( $custom->find($id ) ){
		//echo "CUSTOMS";
		$db = CustomsDB::getInstance();
	}else{

		$db = DB::getInstance();

	}

	$data_id = $db->query("SELECT  b.branch_credits, ba.credits_issued_to_date, ba.id, ba.payment, ba.loaded_credits 
		FROM branch b 
		INNER JOIN branch_additionals ba ON b.id = ba.branch_id 
		WHERE b.id =  $id");

	if( !$data_id->count() ){
		#NO DATA FOUND IN THE DATABASE
		echo "No invoice data found";

	}else{

		foreach( $data_id->results() as $result ){
			$result->id;
		}

	}



	try{
		#UPDATE THE CREDIT  
		$db->update( 'branch', $id, array(	
				'branch_credits'      	=> $result->branch_credits + $result->loaded_credits,
				'date_modified' 		=> date('Y-m-d')
				
		) );


		$db->update( 'branch_additionals', $result->id, array(	
			'credits_issued_to_date' => $result->credits_issued_to_date + $result->loaded_credits,
			'loaded_credits'		 => 0,
			'payment'      			 => "Success"
			
		) );

		echo "Invoice payment confirmed";

	}catch( Exception $e ){
		die( $e->getMessage() );
	} 


}



#ACTIVATE
if( Input::get('action') == _ACTIVATE ){

	$id = Input::get('activate_id');

	$custom 	= new CustomsBranch();
	if( $custom->find($id ) ){
		//echo "CUSTOMS";
		$db = CustomsDB::getInstance();
	}else{

		$db = DB::getInstance();

	}
	

	$data = $db->query("SELECT credit_status, id FROM branch_additionals WHERE branch_id = $id");
	if( !$data->count() ){
	    #NO DATA FOUND IN THE DATABASE
		echo "No credit data found";

	}else{

		 foreach( $data->results() as $result ){
		 	$result->id;

		 	if( $result->credit_status == "Active" ){
		 		$status = "Inactive";

		 	}else{
		 		$status = "Active";
		 	}


		 }

		
		 #UPDATE THE STATUS
		 try{
		      
				$db->update( 'branch_additionals', $result->id, array(	
					'credit_status'      	=> $status
					
				) );

				echo "You have set the credit to " . $status;

		 }catch( Exception $e ){
			die( $e->getMessage() );
		 } 

	}
	

}




#SUSPEND
if( Input::get('action') == _SUSPEND ){

	 //echo "WE ARE SUSPEND";
	$db = DB::getInstance();

	$id = Input::get('suspend_id');

	$data = $db->query("SELECT b.branch_name, ba.suspend_status, ba.id 
		FROM branch b 
		INNER JOIN branch_additionals ba ON b.id = ba.branch_id 
		WHERE b.id = $id");

	if( !$data->count() ){
	    #NO DATA FOUND IN THE DATABASE

			#CUSTOM DATA
			$customs_db = CustomsDB::getInstance();
			
			$customs_data = $customs_db->query("SELECT b.branch_name, ba.suspend_status, ba.id 
				FROM branch b 
				INNER JOIN branch_additionals ba ON b.id = ba.branch_id 
				WHERE b.id = $id");

			if( !$customs_data->count() ){

			    echo "No table data found for this user to suspend";

			}else{

				 foreach( $customs_data->results() as $custom_result ){
				 	
				 	if( $custom_result->suspend_status == 1 ){
				 		$status = 0;

				 	}else{
				 		$status = 1;
				 	}


				 }
				 
				 #UPDATE THE STATUS
				 try{
				 #UPDATE THE CREDIT  

						$customs_db->update( 'branch_additionals', $custom_result->id, array(	
							'suspend_status'      	=> $status
							
						) );

						echo "You have updated the status";

				 }catch( Exception $e ){
					die( $e->getMessage() );
				 } 

			}








	}else{

		 foreach( $data->results() as $result ){
		 	
		 	if( $result->suspend_status == 1 ){
		 		$status = 0;

		 	}else{
		 		$status = 1;
		 	}

		 }
		 
		 #UPDATE THE STATUS
		 try{
		 #UPDATE THE CREDIT  

				$db->update( 'branch_additionals', $result->id, array(	
					'suspend_status'      	=> $status
					
				) );

				echo "You have updated the status";

		 }catch( Exception $e ){
			die( $e->getMessage() );
		 } 

	}



}



?> 